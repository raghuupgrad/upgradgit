BILLING RAGHU STORAGE-FIX BUILD

Upload these two items to the root of your GitHub repository:
1. index.html
2. .github/workflows/android.yml (keep the folder path)

Commit to main, then run Actions > Build Billing raghu APK.

This version stores invoice and Recycle Bin records in Android SharedPreferences
through a JavaScript bridge. It does not need broad storage permission because
SharedPreferences uses the app's private internal storage.

Important: install the new APK as an update over the existing app where possible.
Do not uninstall or clear storage on the old app before backing up existing bills.
The previous app's WebView localStorage may not automatically migrate into the
new native SharedPreferences store. Export/retain any important old bill records
before replacing the app.
