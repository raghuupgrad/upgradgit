package com.gundrathy.invoicemanager;
import android.app.Activity;
import android.os.Bundle;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.net.Uri;
import android.print.PrintAttributes;
import android.print.PrintManager;
import android.util.Base64;
import android.webkit.JavascriptInterface;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import androidx.core.content.FileProvider;
import java.io.File;
import java.io.FileOutputStream;

public class MainActivity extends Activity {
  WebView webView;
  SharedPreferences storage;
  public class AndroidStorage {
    @JavascriptInterface public String getItem(String k){return storage.getString(k,null);}
    @JavascriptInterface public void setItem(String k,String v){storage.edit().putString(k,v).commit();}
    @JavascriptInterface public void removeItem(String k){storage.edit().remove(k).commit();}
    @JavascriptInterface public void clear(){storage.edit().clear().commit();}
  }
  public class AndroidPrint {
    @JavascriptInterface public void printPage(){runOnUiThread(()->{
      PrintManager pm=(PrintManager)getSystemService(Context.PRINT_SERVICE);
      pm.print("Billing raghu Invoice",webView.createPrintDocumentAdapter("Billing raghu Invoice"),
        new PrintAttributes.Builder().setMediaSize(PrintAttributes.MediaSize.ISO_A4).build());
    });}
  }
  public class AndroidShare {
    @JavascriptInterface public void sharePdf(String data,String name){runOnUiThread(()->{
      try {
        byte[] bytes=Base64.decode(data,Base64.DEFAULT);
        File dir=new File(getCacheDir(),"shared"); dir.mkdirs();
        File file=new File(dir,name.replaceAll("[^A-Za-z0-9._-]","_"));
        try(FileOutputStream out=new FileOutputStream(file)){out.write(bytes);}
        Uri uri=FileProvider.getUriForFile(MainActivity.this,getPackageName()+".provider",file);
        Intent send=new Intent(Intent.ACTION_SEND);
        send.setType("application/pdf"); send.putExtra(Intent.EXTRA_STREAM,uri);
        send.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
        startActivity(Intent.createChooser(send,"Share invoice PDF"));
      } catch(Exception e) { android.widget.Toast.makeText(MainActivity.this,"Unable to share PDF: "+e.getMessage(),android.widget.Toast.LENGTH_LONG).show(); }
    });}
  }
  public void onCreate(Bundle b){super.onCreate(b);
    storage=getSharedPreferences("billing_raghu_invoice_data",MODE_PRIVATE);
    webView=new WebView(this);setContentView(webView);
    WebSettings s=webView.getSettings();s.setJavaScriptEnabled(true);s.setDomStorageEnabled(true);
    webView.addJavascriptInterface(new AndroidStorage(),"AndroidStorage");
    webView.addJavascriptInterface(new AndroidPrint(),"AndroidPrint");
    webView.addJavascriptInterface(new AndroidShare(),"AndroidShare");
    webView.setWebViewClient(new WebViewClient());webView.loadUrl("file:///android_asset/index.html");
  }
}
