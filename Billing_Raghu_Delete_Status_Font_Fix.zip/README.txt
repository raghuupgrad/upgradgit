BILLING RAGHU - UPDATED FEATURES

Keep your original invoice ZIP in the GitHub repository root. The workflow automatically extracts a ZIP containing index.html when index.html is not already at the root.
Page 3 includes font-size controls from 6 to 20 pt, protected by PIN 2580. Delete and status actions remain protected by PIN 2580. Android app storage uses the native SharedPreferences bridge.
